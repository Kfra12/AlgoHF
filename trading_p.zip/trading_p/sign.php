<!DOCTYPE html>
<html lang="fr">
<!-- The Head-->
<?php include('head.php'); ?>
<!-- End of the Head -->
<!-- body -->

<body class="main-layout inner_page">
    <!-- loader  -->
    <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="" /></div>
    </div>
    <!-- end loader -->
    <!-- The Header -->
    <?php include('header.php'); ?>
    <!-- End of the Header -->

    <center>
        <div class="boxsignform">
            <form class="formsign">
                <p class="titlesign">Register </p>
                <p class="messagesign">Signup now and get full access to our app. </p>
                    <div class="flexsign">
                    <label>
                        <input required="" placeholder="" type="text" class="input">
                        <span>Firstname</span>
                    </label>

                    <label>
                        <input required="" placeholder="" type="text" class="input">
                        <span>Lastname</span>
                    </label>
                </div>  
                        
                <label>
                    <input required="" placeholder="" type="email" class="input">
                    <span>Email</span>
                </label> 
                    
                <label>
                    <input required="" placeholder="" type="password" class="input">
                    <span>Password</span>
                </label>
                <label>
                    <input required="" placeholder="" type="password" class="input">
                    <span>Confirm password</span>
                </label>
                <button class="submitsign">Submit</button>
                <p class="signin">Already have an acount ? <a href="#">Signin</a> </p>
            </form>
        </div>
    </center>

   <!-- footer -->
      <?php include('footer.php'); ?>
   <!-- end footer -->


      <!-- Javascript files-->
      <script src=" js/jquery.min.js "></script>
      <script src=" js/bootstrap.bundle.min.js "></script>
      <script src=" js/jquery-3.0.0.min.js "></script>
      <script src=" js/custom.js "></script>
   </body>
</html>