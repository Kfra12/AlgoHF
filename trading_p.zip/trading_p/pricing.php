<!DOCTYPE html>
<html lang="fr">
<!-- The Head -->
<?php include('head.php'); ?>
<!-- End of the Head -->
<!-- body -->

<body class="main-layout">
    <!-- loader  -->
    <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="" /></div>
    </div>
    <!-- end loader -->
    <!-- The Header -->
    <?php include('header.php'); ?>
    <!-- End of the Header -->

    <!-- pack bot -->
    <center>
        <div class="box">
            <div class="cards__inner">
                <div class="cards__card card">
                    <center><p class="card__heading">Silver</p></center>
                    <p class="card__heading">Free Plan</p>
                    <p class="card__price">$0/month</p>
                    <ul class="card_bullets flow" role="list">
                    <li>Access to all features</li>
                    <li>Unlimited storage</li>
                    <li>No ads</li>
                    </ul>
                    <a class="card__cta cta" href="packsilver.php">Get Started</a>
                </div>
                <div class="overlay cards__inner"></div>
            </div>
        

        
            <div class="cards__inner">
                <div class="cards__card card">
                    <center><p class="card__heading">Gold</p></center>
                    <p class="card__heading">#</p>
                    <p class="card__price">$0/month</p>
                    <ul class="card_bullets flow" role="list">
                    <li>Access to all features</li>
                    <li>Unlimited storage</li>
                    <li>No ads</li>
                    </ul>
                    <a class="card__cta cta" href="packgold.php">Get Started</a>
                </div>
                <div class="overlay cards__inner"></div>
            </div>
        

        
            <div class="cards__inner">
                <div class="cards__card card">
                    <center><p class="card__heading">Platinium</p></center>
                    <p class="card__heading">#</p>
                    <p class="card__price">$0/month</p>
                    <ul class="card_bullets flow" role="list">
                    <li>Access to all features</li>
                    <li>Unlimited storage</li>
                    <li>No ads</li>
                    </ul>
                    <a class="card__cta cta" href="packplatinium.php">Get Started</a>
                </div>
                <div class="overlay cards__inner"></div>
            </div>
        
        </div>

    </center>
    <!-- end pack bot -->

<!-- footer -->
    <?php include('footer.php'); ?>
<!-- end footer -->

      <!-- Javascript files-->
      <script src=" js/jquery.min.js "></script>
      <script src=" js/bootstrap.bundle.min.js "></script>
      <script src=" js/jquery-3.0.0.min.js "></script>
      <script src=" js/custom.js "></script>
      <script src=" js/pricing.js"></script>
   </body>
</html>