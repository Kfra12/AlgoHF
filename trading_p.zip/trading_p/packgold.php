<!DOCTYPE html>
<html lang="fr">
<!-- The Head -->
<?php include('head.php'); ?>
<!-- End of the Head -->
<!-- body -->

<body class="main-layout">
    <!-- loader  -->
    <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="" /></div>
    </div>
    <!-- end loader -->
    <!-- The Header -->
    <?php include('header.php'); ?>
    <!-- End of the Header -->

    <!-- pack1 info -->
        <center>
            <div class="bbox">
                <div class="card_box">
                    <div class="circle"></div>
                    <div class="circle"></div>
                    <div class="card-inner"></div>
                </div>
            </div>
        </center>
    <!-- pack1 info end -->

<!-- footer -->
<?php include('footer.php'); ?>
<!-- end footer -->

      <!-- Javascript files-->
      <script src=" js/jquery.min.js "></script>
      <script src=" js/bootstrap.bundle.min.js "></script>
      <script src=" js/jquery-3.0.0.min.js "></script>
      <script src=" js/custom.js "></script>
   </body>
</html>